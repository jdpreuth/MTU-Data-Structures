package cs2321;

public class Tester {

	// public static void main(String[] args) {
	// // TODO Auto-generated method stub
	// DoublyLinkedList<Integer> list = new DoublyLinkedList<Integer>();
	//
	// list.addFirst(2);
	// list.addFirst(1);
	// list.addLast(3);
	// list.addAfter(list.last(), 4);
	// list.addBefore(list.last(), 10);
	// list.set(list.last(), 20);
	// list.remove(list.first());
	// for (int i : list) {
	// System.out.println(i);
	// }
	// }
}